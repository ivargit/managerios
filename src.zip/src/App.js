import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import firebase from 'firebase';
import ReduxThunk from 'redux-thunk';
import reducers from './reducers';

import { Button, Card, CardSection } from './components/common';
import Router from './Router'

class App extends Component {
  componentWillMount(){

    const config = {
        apiKey: 'AIzaSyA9_xdU6HDOcue9PaC9hrfsSgyJvPyi4XY',
        authDomain: 'managerios-5da19.firebaseapp.com',
        databaseURL: 'https://managerios-5da19.firebaseio.com',
        projectId: 'managerios-5da19',
        storageBucket: 'managerios-5da19.appspot.com',
        messagingSenderId: '251883167323'
      };
      firebase.initializeApp(config);
  }
  render() {
    const store = createStore(reducers, {},applyMiddleware(ReduxThunk));
    return(
      <Provider store={store}>
        <Router />
      </Provider>

    );

  }
}

export default App;
